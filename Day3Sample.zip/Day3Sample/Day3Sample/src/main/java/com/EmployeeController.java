package com;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    private final Map<Integer, Employee> employeeMap = new HashMap<>();

    // POST - create new employee
    @PostMapping // http://localhost:8080/api/employees
    public ResponseEntity<Employee> createEmployee(@Valid @RequestBody Employee employee) {
        employeeMap.put(employee.getId(), employee);

        // Save all employees to a single JSON file
        ObjectMapper mapper = new ObjectMapper();
        try {
            File file = new File("all_employees.json");
            mapper.writerWithDefaultPrettyPrinter().writeValue(file, employeeMap.values());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ResponseEntity.status(201).body(employee);
    }

    // GET all employees
    @GetMapping // http://localhost:8080/api/employees
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(new ArrayList<>(employeeMap.values()));
    }

    // GET by ID (PathVariable)
    @GetMapping("/{id}") // http://localhost:8080/api/employees/101
    public ResponseEntity<Employee> getEmployeeById(@PathVariable int id) {
        Employee emp = employeeMap.get(id);
        if (emp == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(emp);
    }

    // DELETE employee by ID
    @DeleteMapping("/{id}") // http://localhost:8080/api/employees/101
    public ResponseEntity<String> deleteEmployeeById(@PathVariable int id) {
        if (employeeMap.containsKey(id)) {
            employeeMap.remove(id);

            // Save the updated list to JSON file
            ObjectMapper mapper = new ObjectMapper();
            try {
                File file = new File("all_employees.json");
                mapper.writerWithDefaultPrettyPrinter().writeValue(file, employeeMap.values());
            } catch (IOException e) {
                e.printStackTrace();
            }

            return ResponseEntity.ok("Employee with ID " + id + " deleted successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}