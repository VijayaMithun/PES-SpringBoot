package com;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Employee {
    private int id;

    @NotBlank(message = "Name is required") // Name validation
    private String name;

    @NotNull(message = "Salary must not be null") // salary validation
    private Double salary;

    @Valid
    @NotNull(message = "Address is required")
    private Address address;
    
    public Employee() {
    }

    public Employee(int id, @NotBlank(message = "Name is required") String name,
            @NotNull(message = "Salary must not be null") Double salary, Address address) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.address = address;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Employee(int id, String name, Double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

}
