package com;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {
    private final Map<Integer, Address> addressMap = new HashMap<>();

    // Add or update address
    @PostMapping("/{id}") // http://localhost:8080/api/addresses/1
    public ResponseEntity<String> addOrUpdateAddress(@PathVariable int id, @Valid @RequestBody Address address) {
        addressMap.put(id, address);
        return ResponseEntity.ok("Address saved/updated successfully for ID: " + id);
    }
}
